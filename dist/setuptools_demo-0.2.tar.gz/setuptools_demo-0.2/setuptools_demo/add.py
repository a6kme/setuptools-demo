import numpy


def add(*numbers):
    """
    Add all the numbers and return the sum.
    Ignore any bad input.
    """
    return numpy.add(*numbers)
