# setuptools-demo
A sample repository to test setuptools https://github.com/pypa/setuptools
